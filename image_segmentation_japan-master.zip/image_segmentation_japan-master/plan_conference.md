# Proposal

- core is AI work of me
- three subsession:
  - one AI focused
  - application building energy model
  - street assecement of street comfort, walkability

- six papers minimum 
- talk how roger can collaberate in first part with his work
- one or two paragraph 